# 我的第二周作业提交说明（实验记录）

原始文件：`2026-capstone/week02-llm-application/提交/提交说明.md`


- 姓名：姜楠翔
- 学号：23230610

## 运行环境与命令

- 模型、设备与精度：Qwen2.5-1.5B-Instruct（沿用第一周本地模型），NVIDIA RTX PRO 6000 Blackwell Max-Q（CUDA 12.8），bfloat16
- 依赖版本：Python 3.12.13，torch 2.7.1+cu128，transformers 4.51.3，openai 1.109.1，pydantic 2.11.7，fastapi 0.116.1，uvicorn 0.35.0

示例运行（原版 `llm_app.py`，模型目录为第一周下载的本地目录）：

```bash
M=../第一周_LLM推理/models/Qwen2.5-1.5B-Instruct
python llm_app.py --model $M --device cuda --output results/plain.json
python llm_app.py --model $M --device cuda --stream --example --output results/example.json
# 多轮：第二轮输入“请改用普通 for 循环，并增加注释说明零不算正数。继续返回相同结构的 JSON。”，然后 /exit
python llm_app.py --model $M --device cuda --stream --example --chat --output results/example_chat.json
```

拓展运行（修改后的 `llm_app.py`，`T` 依次取 `count_positive`、`rle`、`second_largest`）：

```bash
python llm_app.py --model $M --device cuda --stream --task tasks/$T.json --repair 0 --output results/ext_${T}_repair0.json
python llm_app.py --model $M --device cuda --stream --task tasks/$T.json --repair 3 --output results/ext_v2_${T}_repair3.json
python llm_app.py --model $M --device cuda --stream --task tasks/$T.json --repair 3 --repair-mode fresh --output results/ext_v3fresh_${T}_repair3.json
```

## 示例运行观察

| 运行 | 结果 |
| --- | --- |
| 普通回答 `plain.json` | `text_received`，216 tokens，6.23 s。返回 Markdown 围栏包裹的代码和解释，函数名是模型自己取的 `count_positive_numbers`，无法直接被程序使用 |
| 流式 + 结构化 `example.json` | `schema_valid` + `syntax_valid`，58 tokens，总耗时 2.21 s，首段文本 1.10 s 到达。代码正确 |
| 多轮 `example_chat.turn01/02.json` | 两轮都是 `schema_valid` + `syntax_valid`。第二轮加上了逐行注释，但没有写出“零不算正数”这一点，只部分遵从了要求 |

## 拓展与结果

- **拓展内容：自动测试 + 带反馈的自动修复。** 原脚本只检查 JSON、字段和语法，明确写着“功能正确性尚未验证”；遇到格式或语法错误时也只能由人手动再提要求。我想让它自动判断代码是否真的可用，不可用时把具体错误反馈给模型，自动重试。

- **主要改动**（均在 `llm_app.py` 中，另新增 `tasks/*.json` 三个任务文件）：
  1. `--task`：读取任务 JSON（`prompt`、`function_name`、`tests`），自动开启结构化校验。
  2. `CodeResult` 收紧约束：`function_name` 必须是合法标识符，`code` 不能为空。
  3. `validate_text` 在原有三层检查后增加两层：一是用 `ast` 检查 `code` 顶层确实定义了约定名字的函数，二是 `run_tests` 在 `python -I` 隔离子进程中执行代码、逐条比对测试用例（比较值和类型，5 秒超时防止死循环）。结果写入 `result.function_check`、`result.tests`，并给出总判定 `result.passed`。
  4. `repair_feedback`：把每种失败（JSON 解析 / 字段 / 语法 / 函数名 / 测试失败 / 运行异常）转成一条具体的修改要求。
  5. `--repair N`：未通过且回答完整时，自动发出反馈并重试，最多 N 轮。每轮单独保存为 `.turnNN.json`，记录 `prompt_source`（user / auto_repair）和 `repair_round`。
  6. `--repair-mode`：`history` 在对话中追加修改要求；`fresh` 丢弃失败回答，重新发送原始要求并附上问题说明。
  7. 迭代过程：v1 语法错误反馈只有行号；v2 增加出错行原文；v3 增加 fresh 模式。

- **运行结果**（三个任务，greedy 解码，修复上限 3 轮）：

  | 任务（测试数） | 不修复 `repair0` | v1 history（仅行号） | v2 history（+出错行原文） | v3 fresh |
  | --- | --- | --- | --- | --- |
  | count_positive (5) | ✗ JSON 解析失败 | ✓ 第 3 轮通过 5/5 | ✓ 第 3 轮通过 5/5 | ✓ **第 1 轮通过 5/5** |
  | second_largest (7) | ✗ 语法错误 | ✗ 3 轮仍失败 | ✗ 3 轮仍失败 | ✓ **第 2 轮通过 7/7** |
  | rle 游程编码 (7) | ✗ 语法错误 | ✗ 3 轮仍失败 | ✗ 3 轮仍失败 | ✗ 3 轮仍失败 |

  验证方式：
  - 最终通过的代码都由 `run_tests` 实际执行测试。以 `second_largest` 为例，修复后的 `sorted(set(nums))[-2]` 通过了重复值、全相同、空列表、负数等 7 个用例。
  - 反馈函数对 7 类失败的判定和反馈文字，我先用构造的输入离线检查过。
  - 修改后的脚本跑原有的 plain / example / chat 流程，输出与原版逐字一致。

- **观察与问题**：
  1. 没有外部校验时，小模型的第一次输出三个任务都不可用。其中 `count_positive` 在 `EXAMPLE_PROMPT` 下能写对，换成我的 Prompt 写法就把 `)` 写成了 `}`。可见输出对 Prompt 措辞很敏感，程序校验是必要的。
  2. history 模式下，模型几乎原样照抄历史里自己的错误代码。v2 已经把出错行原文放进反馈，仍然没有改善，所以问题不在于“找不到错在哪”。原因是 temperature 固定为 0 的 greedy 解码加上错误答案留在上下文里，模型倾向于复制上文。
  3. fresh 模式把错误答案移出上下文，只保留问题说明，三个任务里修好了两个，修复轮数也更少。这是本次最明确的结论。
  4. `rle` 始终没修好：fresh 模式下模型开始在 `code` 里写中文伪代码，这是 1.5B 模型的能力边界。可能的后续改进：在任务 Prompt 中给出示例代码，或者换 3B 模型。
  5. 局限：本次三个任务都没有出现“语法正确但测试不通过”的回答，所以测试失败反馈这条路径只做了离线验证，没有在真实模型上触发。另外，反馈里会写出失败用例，存在模型针对用例写特判的风险，Prompt 中已要求不要特判。执行生成代码只做了子进程隔离和超时，不是完整沙箱，只适合在本机实验中使用。

## 提交文件

- 应用脚本及配套文件：`llm_app.py`（修改后），`tasks/count_positive.json`，`tasks/rle.json`，`tasks/second_largest.json`
- 运行结果：
  - 示例运行（原版脚本）：`results/plain.json`，`results/example.json`，`results/example_chat.turn01.json`，`results/example_chat.turn02.json`
  - 拓展，不修复对照：`results/ext_{count_positive,rle,second_largest}_repair0.json`
  - 拓展 v1（history，仅行号，由加入出错行原文之前的脚本版本产生）：`results/ext_v1_*_repair3.turnNN.json`
  - 拓展 v2（history）：`results/ext_v2_*_repair3.turnNN.json` 及终端日志 `results/ext_v2_*.log`
  - 拓展 v3（fresh）：`results/ext_v3fresh_*_repair3.turnNN.json` 及终端日志 `results/ext_v3fresh_*.log`
