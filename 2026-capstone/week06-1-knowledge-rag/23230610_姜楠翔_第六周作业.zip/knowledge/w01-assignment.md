# 第一周作业要求

原始文件：`2026-capstone/week01-llm-inference/assignment.md`


## 任务

1. 使用 Transformers 运行 Qwen2.5-1.5B-Instruct 或 Qwen2.5-3B-Instruct，CPU 或 GPU 均可。
2. 自选一个问题，记录输入、模型输出、单次推理时间及实际生成 token 数。
3. 使用 `--debug` 打印 hidden states 的形状和部分数值，保存运行结果。

按 模型下载说明 下载后运行：

```bash
python qwen_inference.py --model ./models/Qwen2.5-1.5B-Instruct --device cpu --max-new-tokens 32 --debug --output results/run.json
```

## 提交内容

- 推理脚本（`.py`）。
- 运行结果（JSON 或完整终端日志），包含输入、输出、推理时间、token 数，以及 hidden states 的形状和部分数值。
- 按下方模板填写 `report.md`，与脚本、运行结果一起提交。

无需提交模型权重和虚拟环境。

## 提交模板

复制以下内容到 `report.md`，将占位内容替换为实际运行信息即可。

````markdown
# 第一周作业：Qwen 模型推理

- 姓名：<姓名>
- 学号：<学号>

## 运行环境

- 模型：<模型名称>
- 设备：<CPU/GPU 型号>
- 精度：<如 float32>
- Python / PyTorch / Transformers 版本：<版本号>

## 运行命令

```bash
<填写实际执行的完整命令>
```

## 推理结果

- 输入：<完整问题>
- 输出：<完整模型回答>
- 单次推理时间：<generation_seconds，单位秒>
- 实际生成 token 数：<generated_tokens>
- Hidden states：<状态索引、shape 和部分真实数值，如 hidden_states[-1] 的 [0,-1,:8]>

## 提交文件

- 推理脚本：<文件名.py>
- 运行结果：<文件名.json 或日志文件名>
````
